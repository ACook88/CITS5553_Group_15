import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';

// Entry point for the React application.  This file hooks the root
// element in the HTML template to our App component.  Wrapping
// everything in a BrowserRouter enables client‑side routing via
// react‑router.

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);