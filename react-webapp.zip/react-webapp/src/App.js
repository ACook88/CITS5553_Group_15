import React from 'react';
import { Routes, Route } from 'react-router-dom';
import styled from 'styled-components';

// Import the sidebar and pages.  Keeping these imports
// grouped makes it easier to see the structure of the application.
import Sidebar from './components/Sidebar';
import DataSelection from './pages/DataSelection';
import Comparisons from './pages/Comparisons';
import Export from './pages/Export';
import About from './pages/About';
import Reset from './pages/Reset';

// Define a constant for the width of the sidebar so that it can
// be reused throughout the styled components.  If you decide to
// adjust the width later, you only need to change this value.
const SIDEBAR_WIDTH = '250px';

// The container wraps the entire application except for the
// footer.  Using display: flex allows the sidebar and the main
// content area to sit next to each other horizontally.
const Container = styled.div`
  display: flex;
  min-height: 100vh;
`;

// Main defines the area where routed pages are rendered.
// The margin-left corresponds to the sidebar width so that
// the content does not overlap with the sidebar.  A padding
// is added to give the content some breathing room.
const Main = styled.main`
  flex: 1;
  margin-left: ${SIDEBAR_WIDTH};
  padding: 1.5rem;
  background: #ffffff;
`;

// The footer sticks to the bottom of the viewport and spans
// across the entire width of the page.  Using position: fixed
// keeps it at the bottom regardless of content length.  A
// margin-left equal to the sidebar width prevents overlap with
// the sidebar.
const Footer = styled.footer`
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 40px;
  background-color: #000;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.8rem;
  z-index: 1000;
  /* Offset the footer so that it doesn’t cover the sidebar */
  padding-left: ${SIDEBAR_WIDTH};
`;

/**
 * The App component defines the routing structure for the
 * application.  It renders the Sidebar, the routed pages and
 * the footer.  Each page currently displays placeholder
 * content; actual functionality can be added later.
 */
function App() {
  return (
    <>
      <Sidebar width={SIDEBAR_WIDTH} />
      <Container>
        <Main>
          <Routes>
            <Route path="/" element={<DataSelection />} />
            <Route path="/comparisons" element={<Comparisons />} />
            <Route path="/export" element={<Export />} />
            <Route path="/about" element={<About />} />
            <Route path="/reset" element={<Reset />} />
          </Routes>
        </Main>
      </Container>
      <Footer>
        © Group15 Capstone Project | All rights reserved
      </Footer>
    </>
  );
}

export default App;