import React from 'react';

/**
 * Placeholder component for the About page.  It can later be
 * populated with project information or developer credits.
 */
function About() {
  return (
    <div>
      <h2>About</h2>
      <p>Placeholder</p>
    </div>
  );
}

export default About;