import React from 'react';
import { NavLink } from 'react-router-dom';
import styled from 'styled-components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faTable,
  faChartBar,
  faFileExport,
  faCircleInfo,
  faRotateRight,
  faLayerGroup,
} from '@fortawesome/free-solid-svg-icons';

/**
 * The Sidebar component renders a vertical navigation bar on the left
 * side of the screen.  It receives a width prop from its parent so
 * that the sidebar and main content stay in sync when the width
 * changes.  Each navigation item is defined in the navItems array
 * below.
 */

// Styled component for the container of the sidebar.  It is fixed
// so it remains visible as the user scrolls.  The dark grey
// background colour comes directly from the supplied design.
const SidebarContainer = styled.aside`
  position: fixed;
  top: 0;
  left: 0;
  height: 100vh;
  width: ${({ width }) => width};
  background-color: #222;
  color: #fff;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  z-index: 1001;
`;

// Wrapper for the brand at the top of the sidebar.  We space the
// elements using flexbox to align the icon and the text.  Padding
// provides breathing room around the edges.
const BrandWrapper = styled.div`
  display: flex;
  align-items: center;
  padding: 1rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
`;

const BrandIcon = styled.div`
  font-size: 2rem;
  margin-right: 0.5rem;
`;

const BrandText = styled.h1`
  font-size: 1rem;
  font-weight: 600;
  line-height: 1.2;
  margin: 0;
`;

// Unordered list to hold the navigation items.  Removing default
// margin and padding allows us to control spacing more precisely.
const NavList = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
  flex: 1;
`;

// Individual navigation item.  We use styled NavLink so that we can
// take advantage of the active state provided by react‑router‑dom.
const NavItem = styled(NavLink)`
  display: flex;
  align-items: center;
  padding: 0.75rem 1rem;
  color: #fff;
  text-decoration: none;
  font-size: 0.9rem;
  transition: background 0.2s ease;

  &:hover {
    background-color: #3b3b3b;
  }

  &.active {
    background-color: #6390AC;
  }
`;

// Icon wrapper for consistent sizing and spacing.  Icons from
// FontAwesome are SVGs, so we control the size via the font‑size
// property.  A right margin separates the icon from the label.
const ItemIcon = styled.span`
  font-size: 1rem;
  margin-right: 0.75rem;
  width: 20px;
  display: inline-flex;
  justify-content: center;
`;

const ItemLabel = styled.span`
  flex: 1;
  white-space: nowrap;
`;

// Define the navigation structure here.  Each object describes
// a route, a label for display and an icon definition.  Keeping
// this data in one place makes it easy to adjust the menu order
// or add new routes later.
const navItems = [
  {
    path: '/',
    label: 'Data Selection',
    icon: faTable,
    exact: true,
  },
  {
    path: '/comparisons',
    label: 'Comparisons',
    icon: faChartBar,
  },
  {
    path: '/export',
    label: 'Export',
    icon: faFileExport,
  },
  {
    path: '/about',
    label: 'About',
    icon: faCircleInfo,
  },
  {
    path: '/reset',
    label: 'Reset',
    icon: faRotateRight,
  },
];

function Sidebar({ width }) {
  return (
    <SidebarContainer width={width}>
      <BrandWrapper>
        <BrandIcon>
          <FontAwesomeIcon icon={faLayerGroup} />
        </BrandIcon>
        <BrandText>Data Comparison &amp; Visualisation Tool</BrandText>
      </BrandWrapper>
      <NavList>
        {navItems.map(({ path, label, icon }) => (
          <li key={path}>
            <NavItem to={path} end={path === '/'}>
              <ItemIcon>
                <FontAwesomeIcon icon={icon} />
              </ItemIcon>
              <ItemLabel>{label}</ItemLabel>
            </NavItem>
          </li>
        ))}
      </NavList>
    </SidebarContainer>
  );
}

export default Sidebar;